/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class INTELImmediateExecution {

	/**
	 * cl_command_queue_properties - bitfield 
	 */
	public static final int CL_QUEUE_IMMEDIATE_EXECUTION_ENABLE_INTEL = 0x4;

	/**
	 * cl_device_exec_capabilities - bitfield 
	 */
	public static final int CL_EXEC_IMMEDIATE_EXECUTION_INTEL = 0x4;

	private INTELImmediateExecution() {}
}
