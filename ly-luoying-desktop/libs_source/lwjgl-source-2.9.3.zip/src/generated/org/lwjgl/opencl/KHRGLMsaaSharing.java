/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRGLMsaaSharing {

	/**
	 * cl_gl_texture_info 
	 */
	public static final int CL_GL_NUM_SAMPLES = 0x2012;

	private KHRGLMsaaSharing() {}
}
