/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDBusAddressableMemory {

	/**
	 * cl_mem flag - bitfield 
	 */
	public static final int CL_MEM_BUS_ADDRESSABLE_AMD = 0x40000000,
		CL_MEM_EXTERNAL_PHYSICAL_AMD = 0x80000000,
		CL_COMMAND_WAIT_SIGNAL_AMD = 0x4080,
		CL_COMMAND_WRITE_SIGNAL_AMD = 0x4081,
		CL_COMMAND_MAKE_BUFFERS_RESIDENT_AMD = 0x4082;

	private AMDBusAddressableMemory() {}
}
