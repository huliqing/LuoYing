/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLERgb422 {

	/**
	 *  Accepted by the &lt;format&gt; parameter of DrawPixels, ReadPixels, TexImage1D,
	 *  TexImage2D, GetTexImage, TexImage3D, TexSubImage1D, TexSubImage2D,
	 *  TexSubImage3D, GetHistogram, GetMinmax, ConvolutionFilter1D,
	 *  ConvolutionFilter2D, GetConvolutionFilter, SeparableFilter2D,
	 *  GetSeparableFilter, ColorTable, GetColorTable:
	 */
	public static final int GL_RGB_422_APPLE = 0x8A1F;

	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels, TexImage1D,
	 *  TexImage2D, GetTexImage, TexImage3D, TexSubImage1D, TexSubImage2D,
	 *  TexSubImage3D, GetHistogram, GetMinmax, ConvolutionFilter1D,
	 *  ConvolutionFilter2D, GetConvolutionFilter, SeparableFilter2D,
	 *  GetSeparableFilter, ColorTable, GetColorTable:
	 */
	public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 0x85BA,
		GL_UNSIGNED_SHORT_8_8_REV_APPLE = 0x85BB;

	private APPLERgb422() {}
}
