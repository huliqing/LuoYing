/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTPackedPixels {

	public static final int GL_UNSIGNED_BYTE_3_3_2_EXT = 0x8032,
		GL_UNSIGNED_SHORT_4_4_4_4_EXT = 0x8033,
		GL_UNSIGNED_SHORT_5_5_5_1_EXT = 0x8034,
		GL_UNSIGNED_INT_8_8_8_8_EXT = 0x8035,
		GL_UNSIGNED_INT_10_10_10_2_EXT = 0x8036;

	private EXTPackedPixels() {}
}
