/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureCompressionDXT1 {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of CompressedTexImage2D
	 *  and the &lt;format&gt; parameter of CompressedTexSubImage2D:
	 */
	public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 0x83F0,
		GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 0x83F1;

	private EXTTextureCompressionDXT1() {}
}
