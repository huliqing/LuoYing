/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESRGB8RGBA8 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorageOES: 
	 */
	public static final int GL_RGB8_OES = 0x8051,
		GL_RGBA8_OES = 0x8058;

	private OESRGB8RGBA8() {}
}
